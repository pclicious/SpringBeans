

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;


@Configuration
public class BookConfig {

	@Bean(name="bookBean")
	@Description("This is a sample Book Bean")
	public Book helloWorld() {
		return new BookImpl();
	}

}

import java.rmi.RemoteException;
import java.util.*;
import javax.naming.InitialContext;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import javax.naming.Context;

public class BookClient {
	public static void main(String args[]) throws RemoteException {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(BookConfig.class);
		Book bean = (Book) context.getBean("bookBean");
		bean.addBook("sample");
		System.out.println(bean.getBooks().get(0));
		context.close();

	}
}
import javax.ejb.*;
import java.rmi.*;
import java.util.*;

public interface Book {
	public void addBook(String bname) throws RemoteException;

	public List<String> getBooks() throws RemoteException;
}
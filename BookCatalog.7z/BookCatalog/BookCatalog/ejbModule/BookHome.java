import javax.ejb.*;
import java.rmi.*;


public interface BookHome extends EJBHome {
	public Book create() throws RemoteException, CreateException;
}
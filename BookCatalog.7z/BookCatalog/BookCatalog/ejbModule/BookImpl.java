import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class BookImpl implements Book{

	
	List<String> shelf  = new ArrayList<>();

	public void addBook(String bname) {
		shelf.add(bname);
	}

	public List<String> getBooks() {
		return shelf;
	}
	
}
